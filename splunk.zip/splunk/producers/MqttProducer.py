import json
from datetime import datetime
import paho.mqtt.client as mqtt
# import protobuf


class MqttProducer:
    def __init__(self, config, logger):
        def on_connect(client, data, flags, rc):
            print("connected (%s)" % client._client_id)
        # setup mqtt client and message header
        mqtt_config = config['mqtt']
        self.topic = mqtt_config['topic']
        self.host = mqtt_config['host']
        self.logger = logger
        self.client = mqtt.Client(client_id=self.topic)
        self.client.on_connect = on_connect
        self.client.connect(self.host, port=1883)

        self.message_id = 0
        self._producer = dict(default=self._default_producer,
                              audit_update=self._audit_update_producer)

    def produce(self, message, function="default"):
        try:
            producer = self._producer[function]
        except KeyError as e:
            print(f"Only options: {self._producer.keys()} are supported.")
            raise ValueError(e)
        return producer(message)

    def _default_producer(self, message):
        self.mqtt_message = dict(
            values=[]
            )
        self.mqtt_message['values'] = message
        self.mqtt_message['timestamp'] = int(datetime.utcnow().timestamp())
        self.logger.info(f'producing {len(message)} messages')
        # for testing purpose, add a Kafka header
        self.message_id = self.mqtt_message['timestamp']+1
        kafka_message = dict(id=str(self.message_id),
                             cust_id="3a838c14-7a8e-4bc0-8e30-ea2372f6daec",
                             appliance_id="SNWOOTAPPWC01",
                             source="external_services",
                             type="external_services",
                             message_type=1,
                             payload=self.mqtt_message)
        print(json.dumps(kafka_message))
        """try:
            self.client.publish(self.topic, payload=json.dumps(kafka_message))
        except Exception as e:
            self.logger.error(f'publish error')"""

    def _audit_update_producer(self, message):
        self.mqtt_message = dict(
            message_type="audit_update",
            values=[]
            )
        self.mqtt_message['values'] = message
        self.mqtt_message['timestamp'] = int(datetime.utcnow().timestamp())
        self.logger.info(f'producing {len(message)} messages')
        print(self.mqtt_message)
        """try:
            self.client.publish(self.topic, payload=json.dumps(self.mqtt_message))
        except Exception as e:
            self.logger.error(f'publish error')"""


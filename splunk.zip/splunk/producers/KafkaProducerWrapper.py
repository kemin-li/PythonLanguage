import json
from datetime import datetime
from kafka import KafkaProducer, KafkaConsumer
# import protobuf


class KafkaProducerWrapper(object):
    # kafka interface for produce and consume messages.
    def __init__(self, config, logger):
        kafka_config = config['kafka']
        self.logger = logger
        self.hosts = kafka_config['hosts']
        self.topic_produce = kafka_config['topic_produce']
        self.topic_consume = kafka_config['topic_consume']
        self.producer = KafkaProducer(bootstrap_servers=self.hosts)
        self._producer = dict(default=self._default_producer,
                              audit_update=self._audit_update_producer)

    def produce(self, message, function="default"):
        try:
            producer = self._producer[function]
        except KeyError as e:
            print(f"Only options: {self._producer.keys()} are supported.")
            raise ValueError(e)
        return producer(message)

    def _default_producer(self, message):
        self.mqtt_message = dict(
            values=[]
            )
        self.mqtt_message['values'] = message
        self.mqtt_message['timestamp'] = int(datetime.utcnow().timestamp())
        self.logger.info(f'producing {len(message)} messages')
        # for testing purpose, add a Kafka header
        self.message_id = self.mqtt_message['timestamp']+1
        kafka_message = dict(id=str(self.message_id),
                             cust_id="3a838c14-7a8e-4bc0-8e30-ea2372f6daec",
                             appliance_id="SNWOOTAPPWC01",
                             source="external_services",
                             type="external_services",
                             message_type=1,
                             payload=self.mqtt_message)
        print(json.dumps(kafka_message))
        try:
            self.producer.send(self.topic_produce, json.dumps(kafka_message).encode('utf-8'))
            self.producer.flush()
        except Exception as e:
            self.logger.error(f'publish error: {e}')

    def _audit_update_producer(self, message):
        self.mqtt_message = dict(
            values=[]
        )
        self.mqtt_message['values'] = message
        self.mqtt_message['timestamp'] = int(datetime.utcnow().timestamp())
        self.logger.info(f'producing {len(message)} messages')
        # for testing purpose, add a Kafka header
        self.message_id = self.mqtt_message['timestamp'] + 1
        kafka_message = dict(id=str(self.message_id),
                             cust_id="3a838c14-7a8e-4bc0-8e30-ea2372f6daec",
                             appliance_id="SNWOOTAPPWC01",
                             source="external_services",
                             type="external_services",
                             message_type=1,
                             payload=self.mqtt_message)
        # print(json.dumps(kafka_message))
        # self.producer.send(self.topic_produce, json.dumps(kafka_message).encode('utf-8'))

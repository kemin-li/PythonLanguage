from google.protobuf import json_format
#import eventlib.appliance_msgs.audit_update_pb2
from payload_msgs_pb2 import AuditUpdateMsg, ApplianceMessageType

# update 1
update = AuditUpdateMsg()
update.payload_type = ApplianceMessageType.AUDIT_UPDATE
val1 = AuditUpdateMsg.AuditUpdatePayload(source="source", subsource="subsource",username="username", address="address", ip="ip")
update.values.append(val1)

# update 2
val2 = AuditUpdateMsg.AuditUpdatePayload()
val2.source="s"
val2.subsource="ss"
val2.username="u"
val2.address="add"
update.values.extend([val2])

# serialize/deserialize
print(update.SerializeToString())
u = json_format.MessageToJson(update)
new_update = AuditUpdateMsg()
print(new_update.ParseFromString(u))

#!/usr/bin/env python3
from splunklib.client import connect
from pprint import pprint
def color_text(text, color):
    no_color='\x1b[0m'
    return color+text+no_color
def green_text(text):
    green = '\x1b[1;32m'
    return color_text(text, green)
def blue_text(text):
    blue = '\x1b[1;34m'
    return color_text(text, blue)
def red_text(text):
    red = '\x1b[1;31m'
    return color_text(text, red)

def main():
    opts = dict(
        host="localhost",
        port=8089,
        username="admin",
        password="wootcloud_eval")
    service = connect(**opts)
    saved_searches = service.saved_searches
    print(blue_text("Saved searches..."))
    for ss in saved_searches:
        print(f"-----{ss.name}-----")
        print(ss.history())
        print(ss["search"])
    print(blue_text("Searches..."))
    jobs = service.jobs
    for job in jobs:
        print(f"Search id: {job.sid}")
        pprint(job.content)

if __name__ == "__main__":
    main()

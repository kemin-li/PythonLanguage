import re


class FakeSplunkMapper:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self._mapper = dict(
            splunk=self.extract_username,
            default=self.default_mapper
        )

    def transform(self, data, source_type='splunk'):
        try:
            mapper = self._mapper[source_type]
        except KeyError as e:
            print(f"Only options: {self._mapper.keys()} are supported.")
            raise ValueError(e)
        return mapper(data)

    @staticmethod
    def extract_username(data):
        juniper_pattern = re.compile(
            r".+<134> (.+) : .+ on host \'(.+)\' address '(.+)'\s+for user '(.+)' reason.+")

        mapped = []
        for msg in data:
            matched = re.search(juniper_pattern, msg)
            if matched:
                raw = matched.groups()
                transformed_data = dict(
                    source="splunk",
                    subsource="juniper_vpn",
                    username=raw[3],
                    address=raw[2].replace('-', ':'),
                    ip=raw[1]
                )
                mapped.append(transformed_data)

        return mapped

    @staticmethod
    def default_mapper(data):
        return data

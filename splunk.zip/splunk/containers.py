import logging
import os
import sys
import yaml
# from pymongo import MongoClient
import dependency_injector.containers as containers
import dependency_injector.providers as providers

from consumers.DataFileConsumer import JsonFileConsumer
from mappers.FakeSplunkMapper import FakeSplunkMapper
from producers.mqttProducer import MqttProducer

def get_logger():
    logger = providers.Singleton(logging.Logger, name='splunk_integration')()
    level = logging.DEBUG if os.environ['stage'] == 'dev' else logging.INFO
    logger.setLevel(level)
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level)
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    ch.setFormatter(formatter)
    logger.addHandler(ch)
    return logger


def get_kafka_producer_factory(logger, topic, kafka_config):
    logger.debug(f'Initializing kafka {kafka_config}, {topic}')
    return providers.Factory(KafkaAristaMojoProducer, topic, kafka_config,
                             logger)


def get_splunk_consumer(data_source, config, logger):
    headers = {"Accept": "application/json", "Content-Type": "application/json"}
    consumer = providers.Singleton(AristaAPConsumer,
                                   data_source,
                                   config.runners.arista(),
                                   headers,
                                   logger)
    return consumer


def get_api_runner(consumer, mapper, producer, config, logger):
    credentials_provider = get_mongo_api_credentials_provider(config, logger)
    return providers.Singleton(IntegrationRunner, consumer(), mapper(),
                               producer(), credentials_provider(), logger)


def get_arista_ap_runner(logger, config):
    logger.debug('Initializing get_arista_ap_runner')

    consumer = get_arista_api_consumer('get_ap_devices_url', config, logger)
    mapper = providers.Singleton(AristaAPMapper, logger)
    producer = get_kafka_producer_factory(logger, config.kafka.topic(),
                                          config.kafka.config())
    return get_api_runner(consumer, mapper, producer, config, logger)


def get_mongo_api_credentials_provider(config, logger):
    client = get_mongo_client(config)
    cp_config = config.mongo.credentials()
    return providers.Singleton(MongoApiCredentialsProvider, client, cp_config, logger)


def get_mongo_client(config):
    mongo_config = config.mongo()
    client = MongoClient(mongo_config['urls'])
    return client


def get_mongo_producer(config, logger):
    mongo_client = get_mongo_client(config)
    return providers.Singleton(MongoProducer, mongo_client, config, logger)


def get_splunk_fake_runner(logger, config):
    logger.info('Initializing get_splunk_fake_runner')

    consumer = get_arista_api_consumer('get_ap_devices_url', config, logger)
    mapper = providers.Singleton(AristaAPMapper, logger)
    producer = get_kafka_producer_factory(logger, config.kafka.topic(),
                                          config.kafka.config())
    return get_api_runner(consumer, mapper, producer, config, logger)


def get_splunk_vpn_runner(logger, config):
    logger.info('Initializing get_splunk_vpn_runner')

    consumer = get_arista_api_consumer('get_client_devices_url', config, logger)
    mapper = providers.Singleton(AristaClientMapper, logger)
    producer = get_kafka_producer_factory(logger, config.kafka.topic(),
                                          config.kafka.config())
    return get_api_runner(consumer, mapper, producer, config, logger)


class IocContainer(containers.DeclarativeContainer):
    """IoC container of service providers."""
    print(f"Starting container {os.environ['stage']}")
    with open(f"config-{os.environ['stage']}.yaml", 'r') as yamlfile:
        config = yaml.load(yamlfile, Loader=yaml.SafeLoader)

    provider_config = providers.Configuration('config', default=config)

    logger = get_logger()

    logger.debug(f'Initializing runners with config {config()}')
    arista_ap_devices_runner = get_arista_ap_runner(logger, config)
    arista_client_devices_runner = get_arista_client_runner(logger, config)

    # function_base_template = os.environ['function_arn_template']
    # function_template = function_base_template.format(os.environ)
    # mongo_client = get_mongo_client(config)
    scheduler_config = {'role': os.environ['role']}
    scheduler = providers.Singleton(EventScheduler, function_template, mongo_client, scheduler_config, logger)

    jamf_computers_runner = get_jamf_computers_runner(config, logger)
    jamf_mobile_devices_runner = get_jamf_mobile_devices_runner(config, logger)

    print('Container initialized')

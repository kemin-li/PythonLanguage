import json


class JsonFileConsumer:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        # self._consumer = {}
        self._consumer = {'splunk': self.splunk_consumer}
        self._consumer['default'] = self.default_consumer

    def consume(self, filename, source_type="splunk"):
        try:
            consumer = self._consumer[source_type]
        except KeyError as e:
            print(f"Only options: {self._consumer.keys()} are supported.")
            raise ValueError(e)
        return consumer(filename)

    @staticmethod
    def splunk_consumer(filename):
        data = []
        with open(filename) as fp:
            response = json.load(fp)
        print(type(response), len(response))
        if response:
            data = [e['_raw'] for e in response['results']]
            print(type(data), len(data))
        return data

    @staticmethod
    def default_consumer(filename):
        with open(filename) as fp:
            data = json.load(fp)
        print(type(data), len(data))
        return data

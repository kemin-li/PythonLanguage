import json
import socket
import sys, os
# sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from splunklib.client import connect
import splunklib.results as results

class SplunkApiConsumer:
    def __init__(self, config, logger):
        self.config = config
        self.logger = logger
        self.kwargs = config['sources']['splunk']['kwargs']
        self._consumer = {'splunk': self.splunk_consumer}

    def consume(self, query, source_type="splunk"):
        try:
            consumer = self._consumer[source_type]
        except KeyError as e:
            print(f"Only options: {self._consumer.keys()} are supported.")
            raise ValueError(e)
        return consumer(query, self.kwargs)

    @staticmethod
    def splunk_consumer(query, kwargs):
        def parse(response):
            data = []
            reader = results.ResultsReader(response)
            for result in reader:
                if isinstance(result, dict):
                    data.append(result)
            return data

        service = connect(**kwargs)
        socket.setdefaulttimeout(None)
        response = service.jobs.oneshot(query)
        return parse(response)


import logging
import yaml
from pprint import pprint
from consumers.DataFileConsumer import JsonFileConsumer
from mappers.FakeSplunkMapper import FakeSplunkMapper
from producers.MqttProducer import MqttProducer

with open(f"config-dev.yaml", 'r') as yamlfile:
    config = yaml.load(yamlfile, Loader=yaml.SafeLoader)
print(config)

logger = logging.getLogger(__name__)

#
consumer = JsonFileConsumer(config, logger)
data = consumer.consume("data/juniper_test.json", "splunk")

#
mapper = FakeSplunkMapper(config, logger)
messages = mapper.transform(data, "splunk")

# publish mqtt messages
producer = MqttProducer(config, logger)
producer.produce(messages, function="default")

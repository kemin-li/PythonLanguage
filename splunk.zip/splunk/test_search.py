#!/usr/bin/env python3
from splunklib.client import connect
import splunklib.results as results
from pprint import pprint

def color_text(text, color):
    no_color='\x1b[0m'
    return color+text+no_color
def green_text(text):
    green = '\x1b[1;32m'
    return color_text(text, green)
def blue_text(text):
    blue = '\x1b[1;34m'
    return color_text(text, blue)
def red_text(text):
    red = '\x1b[1;31m'
    return color_text(text, red)

opts = dict(
    host="localhost",
    port=8089,
    username="admin",
    password="wootcloud_eval")
service = connect(**opts)
# Run a one-shot search and display the results using the results reader

# Set the parameters for the search:
# - Search everything in a 24-hour time range starting June 19, 12:00pm
# - Display the first 10 results
kwargs_oneshot = {"earliest_time": "2019-06-20T12:00:00.000-07:00",
                  "latest_time": "2019-06-30T12:00:00.000-07:00"}
#searchquery_oneshot = "search sourcetype=syslog | head 10"
searchquery_oneshot = "search source=/var/log/syslog | head 10"

oneshotsearch_results = service.jobs.oneshot(searchquery_oneshot, **kwargs_oneshot)

# Get the results and display them using the ResultsReader
reader = results.ResultsReader(oneshotsearch_results)
print(green_text(searchquery_oneshot))
for item in reader:
    pprint(item)

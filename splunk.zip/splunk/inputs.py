#!/usr/bin/env python3
from splunklib.client import connect

def main():
    opts = dict(
        host="localhost",
        port=8089,
        username="admin",
        password="wootcloud_eval")
    service = connect(**opts)

    for item in service.inputs:
        header =  "%s (%s)" % (item.name, item.kind)
        print(header)
        print('='*len(header))
        content = item.content
        for key in sorted(content.keys()):
            value = content[key]
            print("%s: %s" % (key, value))
        print()

if __name__ == "__main__":
    main()
